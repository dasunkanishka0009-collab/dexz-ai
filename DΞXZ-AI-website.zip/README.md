# DΞXZ AI

A starter for your own DΞXZ AI website with your supplied logo, a ChatGPT-style interface, and a secure server-side AI API connection.

## Run it

1. Install Node.js 18+.
2. Open this folder in a terminal.
3. Run `npm install`.
4. Copy `.env.example` to `.env`.
5. Put your AI API key in `.env` as `OPENAI_API_KEY=...`.
6. Run `npm start`.
7. Open `http://localhost:3000`.

## Important

Keep the API key on the server. Do not put it inside `public/index.html` or browser JavaScript.

## Publish it

Upload this project to a Node-compatible hosting service, add the same `OPENAI_API_KEY` as a secret/environment variable, and attach your domain when you are ready.
