import "dotenv/config";
import express from "express";
import OpenAI from "openai";

const app = express();
const port = process.env.PORT || 3000;
const client = process.env.OPENAI_API_KEY ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY }) : null;

app.use(express.json({ limit: "1mb" }));
app.use(express.static("public"));

app.post("/api/chat", async (req, res) => {
  try {
    if (!client) return res.status(500).json({ error: "OPENAI_API_KEY is not configured on the server." });
    const messages = Array.isArray(req.body.messages) ? req.body.messages : [];
    const input = messages.slice(-20).map(m => ({
      role: m.role === "assistant" ? "assistant" : "user",
      content: String(m.content || "")
    }));
    const response = await client.responses.create({
      model: "gpt-5.6",
      instructions: "You are DΞXZ AI, a helpful, concise AI assistant. Reply naturally in the user's language.",
      input
    });
    res.json({ reply: response.output_text || "I couldn't generate a response." });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "AI request failed. Check your API key and server logs." });
  }
});

app.listen(port, () => console.log(`DΞXZ AI running on http://localhost:${port}`));
